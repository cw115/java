package com.example.demo.entity;

public enum OpinionType {
    PROS,   // 찬성
    CONS    // 반대
}
